
If you are using an SEW CONTROLLER (DHR41B, DHR21B, etc.) with Fieldbus 
firmware version 13 Release 113 or higher you have to use the SEW_CONTROLLER.EDS file.

Please notice!!!!!!!!!!!!!
If you have already registered the SEW MOVIPLC ADVANCED DHR41B in RSNetworx you have to unregister 
this device prior to registering the SEW_CONTROLLER.EDS
----------------------------------------------------------------------------------------------------

All lower versions of the MOVI-PLC DHR41B are supported in the SEW_MOVIPLC_ADVANCED_DHR41B.EDS file.


